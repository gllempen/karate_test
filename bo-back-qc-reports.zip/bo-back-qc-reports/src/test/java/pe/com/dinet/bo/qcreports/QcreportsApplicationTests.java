package pe.com.dinet.bo.qcreports;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import com.intuit.karate.junit5.Karate;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@KarateOptions(tags = {"@readCsv1"})

class QcreportsApplicationTests {


	@Karate.Test
	Karate testAll() {
		return Karate.run().relativeTo(getClass());
	}

	@Karate.Test
	Karate testUpdateAccountFeature() {
		return Karate.run("classpath:pe/com/dinet/bo/qcreports/karate/suppliers/create.feature").relativeTo(getClass());
	}



}
