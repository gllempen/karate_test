package pe.com.dinet.bo.qcreports.karate.suppliers;

import com.intuit.karate.junit5.Karate;

public class SupplierRunner {

    @Karate.Test
    Karate SupplierRunner(){
        return Karate.run().relativeTo(getClass());
    }

}
