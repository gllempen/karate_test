function fn(jsonPath, fields) {
    var file = karate.read(jsonPath);
    var timestamp = new Date().getTime();
    var random_value = Math.floor(Math.random() * timestamp);

    for (var e of fields) {
        file[e] = file[e] + random_value.toString();
    }

    return file;
}

