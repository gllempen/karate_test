function fn() {
  var config = {
    baseUrl: 'http://4.153.0.119:8001',
    contextPath: '/api/v1/'
  };

  karate.env === 'qa'

  if (karate.env === 'qa') {
    config.baseUrl = 'http://4.153.106.112:8001';
  } else if (karate.env === 'dev') {
    config.baseUrl = 'http://qa.example.com';
  } else if (karate.env === 'local') {
    config.baseUrl = 'http://localhost:8001';
  }

  return config;
}