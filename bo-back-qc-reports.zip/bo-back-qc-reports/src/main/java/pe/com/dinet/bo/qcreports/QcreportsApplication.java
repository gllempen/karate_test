package pe.com.dinet.bo.qcreports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QcreportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(QcreportsApplication.class, args);
	}

}
